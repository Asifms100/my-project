import React, { useState, useEffect } from "react";

export const Home = () => {

    const [data, setData] = useState([]);
    
    useEffect(() => {
      // Simply done to check if the recipe will get displayed or not 
      const fetchData = async () => {
        const item = [
          { id: 1, name: "Biriyani", time: "10:30 AM", image: "book-a.jpg" },
          { id: 2, name: "Noodles", time: "11:00 AM", image: "book-b.jpg" },
          { id: 3, name: "Sandwich", time: "12:15 PM", image: "book-c.jpg" },
          { id: 4, name: "Pasta", time: "10:30 AM", image: "book-a.jpg" },
          { id: 5, name: "Dosa", time: "11:00 AM", image: "book-b.jpg" },
          { id: 6, name: "Ice-cream", time: "12:15 PM", image: "book-c.jpg" },
          { id: 7, name: "Chopsy", time: "10:30 AM", image: "book-a.jpg" },
          { id: 8, name: "Ramen", time: "11:00 AM", image: "book-b.jpg" },
          { id: 9, name: "Sushi", time: "12:15 PM", image: "book-c.jpg" },
        ];
        setData(item);
      };
  
      fetchData();
    }, []);


      // codes for pagination
  const[currentPage, setCurrentPage]=useState(1); 

  const[searchItem,setSearchItem]=useState('')

  const filterData = data.filter((item)=>
    item.name.toLowerCase().includes(searchItem.toLowerCase())
  )

  const recordPerPage = 4; // used to set no:of records to be shown per page
  const lastIndex =currentPage * recordPerPage;
  const firstIndex= lastIndex - recordPerPage;
  const records = filterData.slice(firstIndex, lastIndex);
  const npage= Math.ceil(data.length / recordPerPage);
  const numbers = [...Array(npage + 1).keys()].slice(1);

  function prevPage(){
    if(currentPage !== 1 ){
      setCurrentPage(currentPage - 1);
    }
  }

  function nextPage(){
    if(currentPage !== npage ){
      setCurrentPage(currentPage + 1);
    }
  }

  function changePage(id){
    setCurrentPage(id)
  }
  


    return (
      <>
        {/* Quote on the top-left, but pushed below the navbar */}
        <span 
          style={{
            position: "absolute",  
            top: "100px",           // Adjust to avoid navbar overlap
            left: "10px",         
            fontSize: "40px",     
            fontWeight: "bold",   
            color: "#333",        
          }}
        >
          <p>Discover delicious recipes, cook like a pro, and explore a world of flavors—all in one place! </p>
          
        </span>
  
        {/* Image on the right */}
        <img 
          src="pic1.png" 
          style={{ display: "block", marginLeft: "auto", marginTop: "150px" ,width:"450px",height:"450px"}} // Push image down too
        />
  
        {/* SVG Background */}
        <svg 
          xmlns="http://www.w3.org/2000/svg" 
          viewBox="0 0 1440 320" 
          style={{ marginTop: "-170px" }}  
        >
          <path fill="#FCBF49" fillOpacity="1" d="M0,32L40,48C80,64,160,96,240,112C320,128,400,128,480,144C560,160,640,192,720,176C800,160,880,96,960,90.7C1040,85,1120,139,1200,186.7C1280,235,1360,277,1400,298.7L1440,320L1440,320L1400,320C1360,320,1280,320,1200,320C1120,320,1040,320,960,320C880,320,800,320,720,320C640,320,560,320,480,320C400,320,320,320,240,320C160,320,80,320,40,320L0,320Z"></path>
        </svg>

          {/* code to display each dish */}
        <div className="row mx-4" style={{display: "flex", justifyContent: "center", marginTop:"20px"}}>
        {records.map((item) => {
          return ( // You need a return statement here
            <div className="col-12 col-sm-6 col-md-4 col-lg-3" key={item.id}>
              <div className="card" style={{ width: '280px', height:"350px" }}>
                {/* <Link to={`/book/${item.id}`}> */}
                <img src="plate.jpg" className="card-img-top" alt="oops" style={{height: '340px', alignContent: 'center'}} />
                {/* </Link> */}
                <div className="card-body">
                  <h5 className="card-title">{item.name}</h5>
                  <p className="card-text"><strong>{item.time}</strong></p>
                </div>
              </div>
            </div>
          );
        })}
        </div>

        {/* code to do pagination */}
        <nav aria-label="Page navigation example"
          style={{ display: "flex", justifyContent: "center", marginTop: "30px" }}
        >
  <ul className="pagination">
    <li className="page-item">
      <button className="page-link" onClick={prevPage} disabled={currentPage === 1}>
        Previous
      </button>
    </li>

    
    {
      numbers.map((n,i)=>(
        <li className={`page-item ${currentPage === n ? 'active' : ''}`} key={i}>
          <button className="page-link" onClick={()=>changePage(n)}> {n} </button></li>
      ))
    }
    

    <li className="page-item">
      <button className="page-link" onClick={nextPage} disabled={currentPage === npage}>
        Next
      </button>
    </li>
  </ul>
</nav>
      </>
    )
  } 